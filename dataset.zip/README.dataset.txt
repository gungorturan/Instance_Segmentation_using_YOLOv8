# INDIVIDUAL TEETH LABELLING > 2024-01-06 12:47pm
https://universe.roboflow.com/project-1-qfzls/individual-teeth-labelling-wa1cf

Provided by a Roboflow user
License: CC BY 4.0

